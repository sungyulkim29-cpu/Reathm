# Rhythm Tribute 🎷💀

크레이지아케이드 오마주 프로젝트의 연장선으로 만든 리듬 게임입니다.
시작 화면에서 **곡**과 **난이도**를 직접 골라서 플레이합니다.
키는 **A · S · D · F** 입니다 (PC 기준, 모바일은 화면 터치).

- 🎷 **The Ol' Jitterbug** — 스윙 튠, 약 22초
- 💀 **Spear of Justice** (UNDERTALE) — 약 115초
- 🔨 **Hammer of Justice** (UNDERTALE) — 약 133초
- 📺 **It's TV Time!** (UNDERTALE) — 약 165초, **홀드 노트 포함**
- 🃏 **The World Revolving** (UNDERTALE, Jevil) — 약 101초
- 🌻 **Flower Man** (DELTARUNE Ch.5) — 약 192초, **홀드 노트 포함**

여섯 곡 다 실제 음원을 분석(스펙트럼 온셋 검출)해서 곡의 비트에 맞춰 노트를 배치했고,
난이도별로 노트 밀도와 판정 폭이 다릅니다.

| 난이도 | 노트 밀도 | 판정 폭(PERFECT) | 낙하 속도 |
|---|---|---|---|
| 쉬움 | 적음 | ±160ms | 느림 (2.6초) |
| 보통 | 표준 | ±110ms | 표준 (2.1초) |
| 어려움 | 많음 | ±70ms | 빠름 (1.6초) |

## 폴더 구성

```
repo/
├── .streamlit/
│   └── config.toml     # 정적 파일 서빙 활성화 (enableStaticServing)
├── static/
│   ├── audio/           # 곡별 mp3 원본 파일
│   └── img/              # 곡별 배경 이미지 원본 파일
├── app.py                # Streamlit 진입점 (game.html을 iframe으로 띄움)
├── game.html              # 실제 게임 (순수 HTML/JS, /app/static/... URL로 미디어 참조)
└── requirements.txt        # streamlit 의존성
```

**이번에 구조를 바꿨어요**: 예전엔 오디오/이미지를 base64로 `game.html` 안에 통째로 욱여넣어서 파일이
20MB 넘게 부풀었는데, 이제는 `static/` 폴더에 원본 파일 그대로 두고 게임은 `/app/static/audio/...mp3`,
`/app/static/img/...` 같은 URL로 불러옵니다. `game.html`은 이제 코드 + 노트 타이밍 데이터만 들어있어서
150KB 정도로 훨씬 가벼워요. 이 방식이 동작하려면 `.streamlit/config.toml`에
`enableStaticServing = true`가 켜져 있어야 하는데, 이미 넣어뒀습니다.

**홀드 노트 (Hold Note)**: "It's TV Time!"과 "Flower Man"에는 일부 노트가 길쭉한 막대로 표시되는데, 이건 탭이 아니라 막대 길이만큼 **누르고 있어야** 판정을 받는 노트예요. 너무 일찍 떼면 판정이 깎이고, 아예 안 누르면 미스가 됩니다. 다른 곡들은 전부 일반 탭 노트만 있어요.

**타격 이펙트**: 아무 패드나 누르면 그 패드 안에서만 작은 링+파티클이 터지는 이펙트가 나와요. 노트가 떨어지는 판정선/레인 영역은 건드리지 않아서 플레이 시야를 가리지 않습니다.

## 로컬에서 먼저 확인하기

```bash
pip install streamlit
streamlit run app.py
```

`static/` 폴더가 `app.py`와 같은 위치에 있어야 미디어가 정상적으로 로드됩니다(폴더째로 통째로 옮기시면 됩니다).
브라우저가 열리면 곡 → 난이도를 고르고 START(또는 Space)로 시작하세요.

## GitHub에 올리기

1. GitHub에서 새 저장소 생성 (예: `rhythm-tribute`)
2. 로컬에서:

```bash
cd repo
git init
git add .
git commit -m "Add song select + difficulty select rhythm game"
git branch -M main
git remote add origin https://github.com/<본인계정>/rhythm-tribute.git
git push -u origin main
```

> `static/` 폴더에 곡 6개 mp3 + 배경 이미지 6개가 원본 그대로 들어있어서 저장소 전체 용량은 약 15MB입니다.
> GitHub 파일당 제한(100MB)에는 전혀 문제없어요. `.gitignore`가 `.streamlit/`를 제외하지 않는지 확인하세요 —
> `config.toml`이 빠지면 정적 파일 서빙이 꺼져서 오디오/배경이 안 나옵니다.

## Streamlit Community Cloud로 배포하기

1. https://share.streamlit.io 접속 → GitHub 계정으로 로그인
2. **New app** 클릭
3. 저장소 선택, 브랜치 `main`, Main file path `app.py`
4. **Deploy** 클릭 → 1~2분 후 `https://<앱이름>.streamlit.app` 주소로 배포 완료

이후 저장소에 새로 push할 때마다 자동으로 재배포됩니다.

## 노트 데이터는 어떻게 만들었나요?

각 곡마다:
- STFT 기반 스펙트럴 플럭스로 온셋(비트) 검출
- 각 온셋의 스펙트럴 센트로이드(저음~고음 위치)를 4분위로 나눠 A/S/D/F 라인에 배정
- 난이도별로 최소 간격(min gap) 기준으로 노트를 솎아내서 easy/normal/hard 3단계 차트 생성
- 일부 곡은 노트 사이 간격이 충분히 벌어진 지점을 홀드 노트로 변환

다른 곡을 추가하고 싶으시면 mp3(+원하면 배경 이미지)만 올려주세요 — 같은 방식으로 분석해서
`static/`에 원본을 넣고 `SONGS` 목록에 추가해드릴 수 있어요.
