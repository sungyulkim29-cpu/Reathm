# The Ol' Jitterbug — Rhythm Game 🎷

크레이지아케이드 오마주 프로젝트의 연장선으로 만든 짧은 리듬 게임입니다.
업로드하신 "The Ol' Jitterbug" mp3를 실제로 분석(스펙트럼 온셋 검출)해서
곡의 비트에 맞춰 노트를 배치했습니다. D · F · J · K 4키로 플레이합니다.

## 폴더 구성

```
repo/
├── app.py            # Streamlit 진입점 (game.html을 iframe으로 띄움)
├── game.html          # 실제 게임 (순수 HTML/JS, 오디오 base64 내장)
└── requirements.txt   # streamlit 의존성
```

game.html에는 음원이 base64로 통째로 들어있어서 별도 mp3 파일 없이도
Streamlit Cloud에서 바로 재생됩니다.

## 로컬에서 먼저 확인하기

```bash
pip install streamlit
streamlit run app.py
```

브라우저가 열리면 화면 중앙의 START 버튼(또는 Space)을 눌러 시작하세요.
(Claude 아티팩트 미리보기와 달리, 실제 브라우저 탭이라 오디오 자동재생 제한에 안 걸립니다.)

## GitHub에 올리기

1. GitHub에서 새 저장소 생성 (예: `jitterbug-rhythm`), Public/Private 아무거나 OK
2. 로컬에서:

```bash
cd repo
git init
git add .
git commit -m "Add Jitterbug rhythm game"
git branch -M main
git remote add origin https://github.com/<본인계정>/jitterbug-rhythm.git
git push -u origin main
```

> `game.html` 파일이 700KB 정도로 좀 큽니다(음원이 base64로 들어있어서). GitHub 일반 저장소 용량 제한(파일당 100MB)에는 전혀 문제없는 크기라 그냥 커밋하시면 됩니다.

## Streamlit Community Cloud로 배포하기

1. https://share.streamlit.io 접속 → GitHub 계정으로 로그인
2. **New app** 클릭
3. 방금 만든 저장소 선택, 브랜치는 `main`, Main file path는 `app.py`
4. **Deploy** 클릭 → 1~2분 후 `https://<앱이름>.streamlit.app` 주소로 배포 완료

이후 저장소에 새로 push할 때마다 자동으로 재배포됩니다.

## 노트 데이터는 어떻게 만들었나요?

`game.html` 안의 `NOTE_DATA` 배열이 곡 분석 결과입니다:
- STFT 기반 스펙트럴 플럭스로 온셋(비트) 96개 검출
- 각 온셋의 스펙트럴 센트로이드(저음~고음 위치)를 4분위로 나눠 D/F/J/K 라인에 배정
- 판정 윈도우: PERFECT ±70ms, GOOD ±150ms, OK ±220ms

다른 곡으로 새 버전을 만들고 싶으시면 언제든 말씀해주세요 — 같은 방식으로 분석해서 새 `game.html`을 만들어드릴 수 있어요.
